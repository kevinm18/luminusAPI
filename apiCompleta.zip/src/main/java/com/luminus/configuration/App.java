package com.luminus.configuration;

import java.util.ArrayList;

import com.luminus.exception.LuminusException;

public class App {
	public static void main(String[] args) {
		Integer k = 3;
		Integer columnas = 13;
		Boolean buscar = false;
		ArrayList<Double> origen = new ArrayList<Double>();
		origen.add(14.2);
		origen.add(13.7);
		ArrayList<Integer> posiciones = new ArrayList<Integer>();
		posiciones.add(14);
		posiciones.add(15);
		String elemento = "\"caca                     \"";
		String salidaCompleta = "/user/luminus/salidacompleta.txt";
		String salidaOrdenadaCompleta = "/user/luminus/salidaordenadacompleta.txt";
		String salidaK = "/user/luminus/salidak.txt";
		String salidaExcel = "/user/luminus/salidafinal.ods";
		LuminusConfigurationKNN knn = new LuminusConfigurationKNN(k, columnas, buscar, elemento, origen, posiciones,
				salidaOrdenadaCompleta, salidaCompleta, salidaK, salidaExcel);
//		try {
//			knn.createConfiguration("maestro.properties");
//			knn.uploadConfigurations("/nndende/dsds/");
//		} catch (LuminusException e) {
//			e.printStackTrace();
//		}
		Integer posicionResultado = 4;
		ArrayList<String> opciones = new ArrayList<String>();
		opciones.add("N");
		opciones.add("P");
		ArrayList<String> nombres = new ArrayList<String>();
		nombres.add("General");
		nombres.add("Temperatura");
		nombres.add("Humedad");
		nombres.add("Viento");
		nombres.add("Clase");
		String pathSalida = "/user/luminus/ID3/salida.txt";
		String pathIntermedio = "/user/luminus/ID3/pruebasitnermedias/intermedio.txt";
		String pathCarpetaPrueba = "/user/luminus/ID3/pruebasitnermedias/prueba.txt";
		String pathCarpetaJ = "/user/luminus/ID3/pruebasitnermedias/pruebasjob";
		LuminusConfigurationID3 id3 = new LuminusConfigurationID3(posicionResultado, opciones, nombres, pathSalida,
				pathIntermedio, pathCarpetaPrueba, pathCarpetaJ);
		try {
			id3.createConfiguration("id3nuevo.properties");
			id3.uploadConfigurations("/user/luminus/ID3JA/");
		} catch (Exception e) {
			e.printStackTrace();
		}
//		knn.uploadConfigurations();
		try {
//			knn.getDataFromFile("192.168.0.8:9000", "/user/luminus/datos.txt", System.out);
//			knn.uploadFileToHDFS("/home/maestroluminuscom/Escritorio/procedimiento.txt", "/user/luminus/");
			// knn.deleteFromHDFS("/user/luminus/configuracion.properties");
//			knn.getDataFromFile("/user/luminus/procedimiento.txt", System.out);
//			knn.deleteFromHDFS("/user/cachiporra/");
			// knn.makeHDFSDirectory("/user/cachiporra/");
//			System.err.println(knn.existsInHDFS("/user/luminus/proc.txt"));
			// knn.uploadFileToHDFS("/home/maestroluminuscom/Descargas/configuracion.properties",
			// "/user/luminus/configuracion.properties");
//			knn.createConfiguration();
//			knn.getDataFromFile("/user/luminus/configuracion.properties", System.out);
//			TypeManager t = new TypeManager("/home/maestroluminuscom/Escritorio/proyectoknn/tabla.txt",
//					"/home/maestroluminuscom/Descargas/configuracion.properties");
//			System.err.println(t.verifyTypes("KNN"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
