package com.luminus.configuration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import com.luminus.exception.LuminusException;
import com.luminus.hdfs.access.HDFSAccess.Access;

public class LuminusConfiguration {

	/**
	 * 
	 */
	protected String propertiesFileName;
	/**
	 * 
	 */
	protected String propertiesFilePathInHDFS;

	/**
	 * 
	 * @param fileName
	 * @throws IOException
	 */
	protected void createFile(String fileName) {
		Access.createLocalFile(fileName);
	}

	/**
	 * 
	 * @param host
	 * @param pathToFile
	 * @param outputStream
	 * @throws IOException
	 */
	protected void getDataFromFile(String path, OutputStream outputStream) throws IOException {
		try {
			Access.getDataFromFile(path, outputStream, Access.getFileSystem(Access.getLocalNetAddress()),
					Access.getLocalNetAddress());
		} catch (LuminusException e) {
			e.printStackTrace();
			System.err.println(e.getEx());
		}
	}

	/**
	 * 
	 * @param path
	 * @throws Exception
	 */
	protected void makeHDFSDirectory(String path) throws Exception {
		try {
			Access.makeHDFSDirectory(path, Access.getFileSystem(Access.getLocalNetAddress()),
					Access.getLocalNetAddress());
		} catch (LuminusException e) {
			e.printStackTrace();
			System.err.println(e.getEx());
		}
	}

	/**
	 * 
	 * @param localPath
	 * @param hdfsPath
	 * @throws IOException
	 */
	protected void uploadFileToHDFS(String localPath, String hdfsPath, Boolean overwrite) throws IOException {
		try {
			Access.uploadFileToHDFS(localPath, hdfsPath, Access.getFileSystem(Access.getLocalNetAddress()), overwrite);
		} catch (LuminusException e) {
			e.printStackTrace();
			System.err.println(e.getEx());
		}
	}

	/**
	 * 
	 * @param path
	 * @throws IllegalArgumentException
	 * @throws IOException
	 */
	protected void deleteFromHDFS(String path) throws IllegalArgumentException, IOException {
		try {
			Access.deleteFromHDFS(path, Access.getFileSystem(Access.getLocalNetAddress()));
		} catch (LuminusException e) {
			e.printStackTrace();
			System.err.println(e.getEx());
		}
	}

	/**
	 * 
	 * @param command
	 */
	protected void executeCommand(String[] command) {
		String s = null;
		try {
			Process p = Runtime.getRuntime().exec(command);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
			}
			while ((s = stdError.readLine()) != null) {
				System.out.println(s);
			}
			System.exit(0);
		} catch (IOException e) {

		}
	}

	protected void uploadConfigurations(String propertiesPathInHDFS) throws LuminusException {
		String[] separatedPath = propertiesPathInHDFS.split("/");
		this.propertiesFilePathInHDFS = propertiesPathInHDFS;
		String pathInHDFS = "";
		if (!separatedPath[separatedPath.length - 1].contains(".properties")) {
			for (int i = 0; i < separatedPath.length - 1; i++) {
				if (i == separatedPath.length - 1) {
					continue;
				} else {
					pathInHDFS = pathInHDFS + separatedPath[i] + "/";
				}
			}
			try {
				if (!Access.existsInHDFS(pathInHDFS, Access.getFileSystem(Access.getLocalNetAddress()))) {
					Access.makeHDFSDirectory(pathInHDFS, Access.getFileSystem(Access.getLocalNetAddress()),
							Access.getLocalNetAddress());
				}
				Access.uploadFileToHDFS(propertiesFileName, propertiesFilePathInHDFS + propertiesFileName,
						Access.getFileSystem(Access.getLocalNetAddress()), true);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			throw new LuminusException(6);
		}
	}

	/**
	 * 
	 */
	protected void run(String inputHDFSPath, String outputHDFSPath) {
	}

	/**
	 * 
	 * @return
	 */
	public String getPropertiesFilePathInHDFS() {
		return propertiesFilePathInHDFS;
	}

	/**
	 * 
	 * @param propertiesFilePathInHDFS
	 */
	public void setPropertiesFilePathInHDFS(String propertiesFilePathInHDFS) {
		this.propertiesFilePathInHDFS = propertiesFilePathInHDFS;
	}

	/**
	 * @return the propertiesFileName
	 */
	public String getPropertiesFileName() {
		return propertiesFileName;
	}

	/**
	 * @param propertiesFileName the propertiesFileName to set
	 */
	public void setPropertiesFileName(String propertiesFileName) {
		this.propertiesFileName = propertiesFileName;
	}
}
