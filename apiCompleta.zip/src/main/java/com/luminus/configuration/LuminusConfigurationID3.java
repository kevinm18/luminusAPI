package com.luminus.configuration;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class LuminusConfigurationID3 extends LuminusConfiguration {
	/**
	 * 
	 */
	private Integer resultPosition;
	/**
	 * 
	 */
	private ArrayList<String> classes;
	/**
	 * 
	 */
	private ArrayList<String> headers;
	/**
	 * 
	 */
	private String outputPath;
	/**
	 * 
	 */
	private String intermediatePath;
	/**
	 * 
	 */
	private String testFolderPath;
	/**
	 * 
	 */
	private String jFolderPath;

	/**
	 * 
	 */
	@Override
	public void run(String inputHDFSPath, String outputHDFSPath) {
		try {
			executeCommand(new String[] { "yarn", "jar", "id3.jar", "AlgotimoID3.ID3", inputHDFSPath, outputHDFSPath,
					propertiesFilePathInHDFS + propertiesFileName });
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createConfiguration(String fileName) {
		if (fileName.contains(".properties")) {
			this.propertiesFileName = fileName;
			createFile(propertiesFileName);
			try {
				@SuppressWarnings("resource")
				DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(propertiesFileName));
				dataOutputStream.writeBytes("posicionresultado=" + this.getResultPosition().toString() + "\n");
				dataOutputStream.writeBytes("pathsalida=hdfs:" + this.getOutputPath() + "\n");
				dataOutputStream.writeBytes("pathintermedio=hdfs:" + this.getIntermediatePath() + "\n");
				dataOutputStream.writeBytes("pathcarpetaprueba=hdfs:" + this.getTestFolderPath() + "\n");
				dataOutputStream.writeBytes("pathcarpetaj=hdfs:" + this.getjFolderPath() + "\n");
				Integer counter = 1;
				String clss = "";
				for (String opt : this.getClasses()) {
					clss = clss + opt;
					if (counter == this.getClasses().size()) {
						break;
					}
					clss = clss + ",";
					counter++;
				}
				dataOutputStream.writeBytes("opciones=" + clss + "\n");
				String hdrs = "";
				counter = 1;
				for (String hd : this.getHeaders()) {
					hdrs = hdrs + hd;
					if (counter == this.getHeaders().size()) {
						break;
					}
					hdrs = hdrs + ",";
					counter ++;
				}
				dataOutputStream.writeBytes("nombres=" + hdrs + "\n");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public LuminusConfigurationID3(Integer resultPosition, ArrayList<String> classes, ArrayList<String> headers,
			String outputPath, String intermediatePath, String testFolderPath, String jFolderPath) {
		super();
		this.resultPosition = resultPosition;
		this.classes = classes;
		this.headers = headers;
		this.outputPath = outputPath;
		this.intermediatePath = intermediatePath;
		this.testFolderPath = testFolderPath;
		this.jFolderPath = jFolderPath;
	}

	/**
	 * @return the resultPosition
	 */
	public Integer getResultPosition() {
		return resultPosition;
	}

	/**
	 * @param resultPosition the resultPosition to set
	 */
	public void setResultPosition(Integer resultPosition) {
		this.resultPosition = resultPosition;
	}

	/**
	 * @return the classes
	 */
	public ArrayList<String> getClasses() {
		return classes;
	}

	/**
	 * @param classes the classes to set
	 */
	public void setClasses(ArrayList<String> classes) {
		this.classes = classes;
	}

	/**
	 * @return the headers
	 */
	public ArrayList<String> getHeaders() {
		return headers;
	}

	/**
	 * @param headers the headers to set
	 */
	public void setHeaders(ArrayList<String> headers) {
		this.headers = headers;
	}

	/**
	 * @return the outputPath
	 */
	public String getOutputPath() {
		return outputPath;
	}

	/**
	 * @param outputPath the outputPath to set
	 */
	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}

	/**
	 * @return the intermediatePath
	 */
	public String getIntermediatePath() {
		return intermediatePath;
	}

	/**
	 * @param intermediatePath the intermediatePath to set
	 */
	public void setIntermediatePath(String intermediatePath) {
		this.intermediatePath = intermediatePath;
	}

	/**
	 * @return the testFolderPath
	 */
	public String getTestFolderPath() {
		return testFolderPath;
	}

	/**
	 * @param testFolderPath the testFolderPath to set
	 */
	public void setTestFolderPath(String testFolderPath) {
		this.testFolderPath = testFolderPath;
	}

	/**
	 * @return the jFolderPath
	 */
	public String getjFolderPath() {
		return jFolderPath;
	}

	/**
	 * @param jFolderPath the jFolderPath to set
	 */
	public void setjFolderPath(String jFolderPath) {
		this.jFolderPath = jFolderPath;
	}

}
