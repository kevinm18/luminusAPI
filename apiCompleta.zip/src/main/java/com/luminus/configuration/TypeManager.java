package com.luminus.configuration;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.luminus.exception.LuminusException;

public class TypeManager {
	/**
	 * 
	 */
	private BufferedReader inputFileReader;
	/**
	 * 
	 */
	private Properties propertiesFileReader;
	/**
	 * 
	 */
	private String inputFilePath;
	/**
	 * 
	 */
	private String propertiesFilePath;
	/**
	 * 
	 */
	private final static String POSICIONES_ORIGEN = "posiciones";

	/**
	 * 
	 * @param inputFilePath
	 * @param propertiesFilePath
	 */
	public TypeManager(String inputFilePath, String propertiesFilePath) {
		try {
			inputFileReader = new BufferedReader(new FileReader(inputFilePath));
			InputStream propertiesStream = new FileInputStream(propertiesFilePath);
			propertiesFileReader = new Properties();
			propertiesFileReader.load(propertiesStream);
			this.inputFilePath = inputFilePath;
			this.propertiesFilePath = propertiesFilePath;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param alg
	 * @return
	 */
	public Boolean verifyTypes(String alg) throws LuminusException {
		if (alg == "KNN") {
			return matchColumnWithType(findColumns(POSICIONES_ORIGEN), alg);
		} else if (alg == "ID3") {
			return true;
		} else {
			throw new LuminusException(4);
		}
	}

	/**
	 * 
	 * @param columns
	 * @param alg
	 * @return
	 */
	private Boolean matchColumnWithType(Integer[] columns, String alg) {
		String line;
		String[] elementsInLine;
		Boolean valid = true;
		try {
			line = inputFileReader.readLine();
			while (line != null) {
				if (valid) {
					elementsInLine = line.split(",");
					for (Integer i = 0; i < columns.length; i++) {
						for (Integer j = 0; j < elementsInLine.length; j++) {
							if (columns[i] - 1 == j) {
								try {
									Integer.parseInt(elementsInLine[j]);
									Double.parseDouble(elementsInLine[j]);
									Float.parseFloat(elementsInLine[j]);
									valid = true;
								} catch (NumberFormatException excepcion) {
									valid = false;
								}
							} else {
								continue;
							}
						}
					}
					line = inputFileReader.readLine();
				} else {
					return false;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
	}

	/**
	 * 
	 * @return
	 */
	private Integer[] findColumns(String property) {
		String prop = propertiesFileReader.getProperty(property);
		String[] columnArray = prop.split(",");
		Integer[] integerColumnArray = new Integer[columnArray.length];
		for (int i = 0; i < columnArray.length; i++) {
			integerColumnArray[i] = Integer.parseInt(columnArray[i]);
		}
		return integerColumnArray;
	}

	/**
	 * @return the inputFileReader
	 */
	public BufferedReader getInputFileReader() {
		return inputFileReader;
	}

	/**
	 * @param inputFileReader the inputFileReader to set
	 */
	public void setInputFileReader(BufferedReader inputFileReader) {
		this.inputFileReader = inputFileReader;
	}

	/**
	 * @return the propertiesFileReader
	 */
	public Properties getPropertiesFileReader() {
		return propertiesFileReader;
	}

	/**
	 * @param propertiesFileReader the propertiesFileReader to set
	 */
	public void setPropertiesFileReader(Properties propertiesFileReader) {
		this.propertiesFileReader = propertiesFileReader;
	}

	/**
	 * @return the propertiesFilePath
	 */
	public String getPropertiesFilePath() {
		return propertiesFilePath;
	}

	/**
	 * @param propertiesFilePath the propertiesFilePath to set
	 */
	public void setPropertiesFilePath(String propertiesFilePath) {
		this.propertiesFilePath = propertiesFilePath;
	}

	/**
	 * @return the inputFilePath
	 */
	public String getInputFilePath() {
		return inputFilePath;
	}

	/**
	 * @param inputFilePath the inputFilePath to set
	 */
	public void setInputFilePath(String inputFilePath) {
		this.inputFilePath = inputFilePath;
	}

}
