package com.luminus.configuration;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.Properties;
import com.luminus.exception.LuminusException;

public class LuminusConfigurationKNN extends LuminusConfiguration {

	/*
	 * Atributos de la clase.
	 */

	/**
	 * {@link Integer} k Numero de vecinos que se van a buscar al ejecutar el
	 * algoritmo KNN.
	 */
	private Integer k;
	/**
	 * {@link Integer} columnPositions Posiciones de las columnas.
	 */
	private Integer columnPositions;
	/**
	 * {@link Boolean} search
	 */
	private Boolean search;
	/**
	 * {@link String} searchElement Elemento con el que se van a comparar todos los
	 * vecinos.
	 */
	private String searchElement;
	/**
	 * 
	 */
	private ArrayList<Double> origin;
	/**
	 * 
	 */
	private ArrayList<Integer> positions;
	/**
	 * 
	 */
	private String completeOrderedOutputPath;
	/**
	 * 
	 */
	private String completeOutputPath;
	/**
	 * 
	 */
	private String kOutputPath;
	/**
	 * 
	 */
	private String spreadsheetOutputPath;

	/**
	 * 
	 * @throws IOException
	 */
	public void createConfiguration(String fileName) throws LuminusException {
		if (fileName.contains(".properties")) {
			// Crea el archivo properties.
			this.propertiesFileName = fileName;
			createFile(propertiesFileName);
			try {
				@SuppressWarnings("resource")
				DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(propertiesFileName));
				dataOutputStream.writeBytes("posicionescolumnas=" + this.getColumnPositions().toString() + "\n");
				dataOutputStream.writeBytes("buscar=" + (this.getSearch() ? "S" : "N") + "\n");
				dataOutputStream.writeBytes("elementoabuscar=" + this.getSearchElement() + "\n");
				dataOutputStream.writeBytes("K=" + this.getK().toString() + "\n");
				dataOutputStream.writeBytes("pathsalidaordenadacompleta=hdfs:" + this.getCompleteOrderedOutputPath() + "\n");
				dataOutputStream.writeBytes("pathsalidacompleta=hdfs:" + this.getCompleteOutputPath() + "\n");
				dataOutputStream.writeBytes("pathsalidak=hdfs:" + this.getkOutputPath() + "\n");
				dataOutputStream.writeBytes("pathsalidaexcel=hdfs:" + this.getSpreadsheetOutputPath() + "\n");
				String originProp = "";
				Integer counter = 1;
				for (Double d : this.getOrigin()) {
					originProp = originProp + d.toString();
					if (counter == this.getOrigin().size()) {
						break;
					}
					originProp = originProp + ",";
					counter++;
				}
				dataOutputStream.writeBytes("origen=" + originProp + "\n");
				String positionProp = "";
				counter = 1;
				for (Integer d : this.getPositions()) {
					positionProp = positionProp + d.toString();
					if (counter == this.getPositions().size()) {
						break;
					}
					positionProp = positionProp + ",";
					counter++;
				}
				dataOutputStream.writeBytes("posiciones=" + positionProp + "\n");

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 */
	@Override
	public void run(String inputHDFSPath, String outputHDFSPath) {
		try {
			executeCommand(new String[] { "yarn", "jar", "knn.jar", "DemoPackage.KNN", inputHDFSPath, outputHDFSPath,
					propertiesFilePathInHDFS + propertiesFileName });
			executeCommand(new String[] { "yarn", "jar", "knn.jar", "DemoPackage.KNN", inputHDFSPath, outputHDFSPath,
					propertiesFilePathInHDFS + propertiesFileName });
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 */
	@SuppressWarnings("unused")
	private Boolean isReadyToExecute(String fileName) {
		Properties propertiesFile = new Properties();
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(fileName);
			propertiesFile.load(inputStream);
			if (propertiesFile.getProperty("posicionescolumnas") == "" || propertiesFile.getProperty("buscar") == ""
					|| propertiesFile.getProperty("elementoabuscar") == "" || propertiesFile.getProperty("origen") == ""
					|| propertiesFile.getProperty("posiciones") == "" || propertiesFile.getProperty("K") == ""
					|| propertiesFile.getProperty("pathsalidaordenadacompleta") == ""
					|| propertiesFile.getProperty("pathsalidacompleta") == ""
					|| propertiesFile.getProperty("pathsalidak") == ""
					|| propertiesFile.getProperty("pathsalidaexcel") == ""
					|| propertiesFile.getProperty("posicionescolumnas") == null
					|| propertiesFile.getProperty("buscar") == null
					|| propertiesFile.getProperty("elementoabuscar") == null
					|| propertiesFile.getProperty("origen") == null || propertiesFile.getProperty("posiciones") == null
					|| propertiesFile.getProperty("K") == null
					|| propertiesFile.getProperty("pathsalidaordenadacompleta") == null
					|| propertiesFile.getProperty("pathsalidacompleta") == null
					|| propertiesFile.getProperty("pathsalidak") == null
					|| propertiesFile.getProperty("pathsalidaexcel") == null) {
				return false;
			}
			return true;
		} catch (IOException e) {
		}
		return false;
	}

	/*
	 * Constructor(es).
	 */

	/**
	 * Constructor para algorito KNN.
	 * 
	 * @param k
	 * @param columnPositions
	 * @param search
	 * @param searchElement
	 * @param origin
	 * @param positions
	 * @param completeOrderedOutputPath
	 * @param completeOutputPath
	 * @param kOutputPath
	 * @param spreadsheetOutputPath
	 */
	public LuminusConfigurationKNN(Integer k, Integer columnPositions, Boolean search, String searchElement,
			ArrayList<Double> origin, ArrayList<Integer> positions, String completeOrderedOutputPath,
			String completeOutputPath, String kOutputPath, String spreadsheetOutputPath) {
		super();
		this.k = k;
		this.columnPositions = columnPositions;
		this.search = search;
		this.searchElement = searchElement;
		this.origin = origin;
		this.positions = positions;
		this.completeOrderedOutputPath = completeOrderedOutputPath;
		this.completeOutputPath = completeOutputPath;
		this.kOutputPath = kOutputPath;
		this.spreadsheetOutputPath = spreadsheetOutputPath;
	}

	/*
	 * Getters y Setters.
	 */

	/**
	 * @return the k
	 */
	public Integer getK() {
		return k;
	}

	/**
	 * @param k the k to set
	 */
	public void setK(Integer k) {
		this.k = k;
	}

	/**
	 * @return the columnPositions
	 */
	public Integer getColumnPositions() {
		return columnPositions;
	}

	/**
	 * @param columnPositions the columnPositions to set
	 */
	public void setColumnPositions(Integer columnPositions) {
		this.columnPositions = columnPositions;
	}

	/**
	 * @return the search
	 */
	public Boolean getSearch() {
		return search;
	}

	/**
	 * @param search the search to set
	 */
	public void setSearch(Boolean search) {
		this.search = search;
	}

	/**
	 * @return the searchElement
	 */
	public String getSearchElement() {
		return searchElement;
	}

	/**
	 * @param searchElement the searchElement to set
	 */
	public void setSearchElement(String searchElement) {
		this.searchElement = searchElement;
	}

	/**
	 * @return the origin
	 */
	public ArrayList<Double> getOrigin() {
		return origin;
	}

	/**
	 * @param origin the origin to set
	 */
	public void setOrigin(ArrayList<Double> origin) {
		this.origin = origin;
	}

	/**
	 * @return the positions
	 */
	public ArrayList<Integer> getPositions() {
		return positions;
	}

	/**
	 * @param positions the positions to set
	 */
	public void setPositions(ArrayList<Integer> positions) {
		this.positions = positions;
	}

	/**
	 * @return the completeOrderedOutputPath
	 */
	public String getCompleteOrderedOutputPath() {
		return completeOrderedOutputPath;
	}

	/**
	 * @param completeOrderedOutputPath the completeOrderedOutputPath to set
	 */
	public void setCompleteOrderedOutputPath(String completeOrderedOutputPath) {
		this.completeOrderedOutputPath = completeOrderedOutputPath;
	}

	/**
	 * @return the completeOutputPath
	 */
	public String getCompleteOutputPath() {
		return completeOutputPath;
	}

	/**
	 * @param completeOutputPath the completeOutputPath to set
	 */
	public void setCompleteOutputPath(String completeOutputPath) {
		this.completeOutputPath = completeOutputPath;
	}

	/**
	 * @return the kOutputPath
	 */
	public String getkOutputPath() {
		return kOutputPath;
	}

	/**
	 * @param kOutputPath the kOutputPath to set
	 */
	public void setkOutputPath(String kOutputPath) {
		this.kOutputPath = kOutputPath;
	}

	/**
	 * @return the spreadsheetOutputPath
	 */
	public String getSpreadsheetOutputPath() {
		return spreadsheetOutputPath;
	}

	/**
	 * @param spreadsheetOutputPath the spreadsheetOutputPath to set
	 */
	public void setSpreadsheetOutputPath(String spreadsheetOutputPath) {
		this.spreadsheetOutputPath = spreadsheetOutputPath;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ConfigurationKNN [k=" + k + ", columnPositions=" + columnPositions + ", search=" + search
				+ ", searchElement=" + searchElement + ", origin=" + origin + ", positions=" + positions
				+ ", completeOrderedOutputPath=" + completeOrderedOutputPath + ", completeOutputPath="
				+ completeOutputPath + ", kOutputPath=" + kOutputPath + ", spreadsheetOutputPath="
				+ spreadsheetOutputPath + "]";
	}
}
