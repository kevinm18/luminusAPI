package AlgoritmoID3;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Arrays;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.commons.io.FileUtils;

public class ID3 {
	public static int palabras;
	public static int carpetajob = 0;
	public static int posirec;
	public static ArrayList<Integer> posicion = new ArrayList<Integer>();
	public static ArrayList<String> palabrabuscada = new ArrayList<String>();
	public static String nombrecolumns[];
	public static String construccion = "";
	public static String pathIntermedio = "";
	public static String pathCarpetaJ = "";
	public static String pathCarpetaPrueba = "";
	public static String ubicacionEntrada = "";
	public static String ubicacionProperties = "";
	public static String ubicacionSalida = "";
	public static void main(String[] args) throws Exception {
		ArrayList<String> primero = new ArrayList<String>();
		ubicacionEntrada = args[0];
		ubicacionSalida = args[1];
		ubicacionProperties = args[2];
		try {
			Path pt = new Path(ubicacionEntrada);
			FileSystem fs = FileSystem.get(new Configuration());
			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
			String linealeida;
			linealeida = br.readLine();
			String[] elems = linealeida.split(",");
			palabras = elems.length;
			palabras = palabras - 1;
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		String nombres = "";
		String result = "";
		String pathSalida = "";
		try {
			Properties prop = new Properties();
			Path pt = new Path(ubicacionProperties);// Location of file in HDFS
			FileSystem fs = FileSystem.get(new Configuration());
			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
			prop.load(br);
			nombres = prop.getProperty("nombres");
			result = prop.getProperty("posicionresultado");
			pathSalida = prop.getProperty("pathsalida");
			pathIntermedio = prop.getProperty("pathintermedio");
			pathCarpetaJ = prop.getProperty("pathcarpetaj");
			pathCarpetaPrueba = prop.getProperty("pathcarpetaprueba");
		} catch (Exception e) {
		}
		nombrecolumns = nombres.split(",");
		posirec = Integer.parseInt(result);
		Configuration c = new Configuration();
		String imprimirfinal = recursiva(args[0], args[1], -1, c);
		FileSystem fs1 = FileSystem.get(new Configuration());
		Path escribir1 = new Path(pathSalida);
		if (fs1.exists(escribir1)) {
			fs1.delete(escribir1, true);
		}
		DataOutputStream stm1 = fs1.create(escribir1);
		stm1.writeBytes(construccion);
		stm1.writeBytes("\n");
		stm1.close();
		System.exit(1);
	}
	public static String recursiva(String inputentrada, String outputentrada, int contador, Configuration c)
			throws IOException, ClassNotFoundException, InterruptedException {
		Path input = new Path(inputentrada);
		Path output = new Path(outputentrada);
		Job k = new Job(c);
		k.getConfiguration().set("ubicacionProperties", ubicacionProperties);
		k.getConfiguration().set("ubicacionEntrada", ubicacionEntrada);
		k.getConfiguration().set("ubicacionIntermedio", pathIntermedio);
		k.setJarByClass(ID3.class);
		k.setMapperClass(MapForID3.class);
		k.setReducerClass(ReduceForID3.class);
		k.setOutputKeyClass(Text.class);
		k.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(k, input);
		FileOutputFormat.setOutputPath(k, output);
		k.waitForCompletion(true);
		String linealeida = "";
		int intPrueba = -2;
		try {
			Path pt = new Path(pathIntermedio);
			FileSystem fs = FileSystem.get(new Configuration());
			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));

			linealeida = br.readLine();
			br.close();
		} catch (Exception e) {
		}
		String[] words = null;
		words = linealeida.split(",");
		boolean resint = esEntero(words[words.length - 1]);
		if (resint == true) {
			intPrueba = Integer.parseInt(words[words.length - 1]);
		}
		if (contador == palabras) {
			construccion = construccion + "termine por exceso de intentos";
			return "";
		}

		if (intPrueba == -1) {
			String palabra = "";
			for (int it = 0; it < palabrabuscada.size(); it++) {
				palabra = palabra + "\t ";
			}
			construccion = construccion + palabra +  nombrecolumns[posirec] + " = " + words[0] + "\n";
			System.out.println("la construccion en salida es" + construccion);
			return "";
		}

		if (posicion.contains(intPrueba) == false) {
			posicion.add(intPrueba);
			palabrabuscada.add("");
		}
		System.out.println("acabo de agregar la fila" + intPrueba);
		// si lo contiene
		for (int f = 0; f < words.length - 1; f++) {

			String pat = pathCarpetaPrueba;
			String out = pathCarpetaJ + carpetajob;

			carpetajob++;
			int posi = posicion.indexOf(intPrueba);
			if (palabrabuscada.get(posi).equals(words[f]) == false) {
				palabrabuscada.set(posi, words[f]);
			}
			if (palabrabuscada.size() > 1) {
				String palabra = "";
				for (int it = 0; it < palabrabuscada.size(); it++) {
					palabra = palabra + "\t ";
				}
				construccion = construccion + palabra + " if (" + nombrecolumns[posicion.get(posi)] + " =="
						+ palabrabuscada.get(posi) + ") \n";
			} else {
				construccion = construccion + "if (" + nombrecolumns[posicion.get(posi)] + " =="
						+ palabrabuscada.get(posi) + ") \n";
			}
			System.out.println("la construccion aqui es" + construccion);
			System.out.println("traigo en posicion" + posicion.get(posi));
			System.out.println("traigo en palabra buscada " + palabrabuscada.get(posi));
			subtabla(posicion, palabrabuscada, pat);
			recursiva(pat, out, contador + 1, c);
		}
		int posit = posicion.indexOf(intPrueba);
		posicion.remove(posit);
		palabrabuscada.remove(posit);
		System.out.println("acabo de borrar la fila" + posit);
		return "";
	}

	public static boolean esEntero(String cadena) {
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException excepcion) {
			return false;
		}
	}

	public static void subtabla(ArrayList<Integer> x, ArrayList<String> Buscar, String path) throws IOException {
		System.out.println("para" + Buscar);
		ArrayList<String> escribir = new ArrayList<String>();
		ArrayList<String> respaldo = new ArrayList<String>();
		try {
			int validador = 0;
			Path pt = new Path(ubicacionEntrada);
			FileSystem fs = FileSystem.get(new Configuration());
			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
			String linealeida;
			linealeida = br.readLine();
			while (linealeida != null) {
				String[] elems = linealeida.split(",");
				for (int ma = 0; ma < x.size(); ma++) {
					if (elems[x.get(ma)].equals(Buscar.get(ma))) {
						validador = validador + 1;
					}
				}
				if (validador == x.size()) {
					escribir.add(linealeida);
					System.out.println("voy a escribir" + linealeida);
				}
				validador = 0;
				linealeida = br.readLine();
			}
			br.close();
		} catch (Exception e) {
		}
		FileSystem fs2 = FileSystem.get(new Configuration());
		Path escribir2 = new Path(path);
		if (fs2.exists(escribir2)) {
			fs2.delete(escribir2, true);
		}
		DataOutputStream stm2 = fs2.create(escribir2);
		for (int i = 0; i < escribir.size(); i++) {
			stm2.writeBytes(escribir.get(i));
			stm2.writeBytes("\n");
		}
		stm2.close();
	}

	public static class MapForID3 extends Mapper<LongWritable, Text, Text, IntWritable> {
		public static List<Estructura> listaid3 = new ArrayList<Estructura>();
		public static int salidas[];
		public static boolean paso = false;
		public static int posirec;
		public static String[] origenarray;
		protected void setup(Context context) throws IOException, InterruptedException {
			String posicion = "";
			String opcion = "";
			try {
				Properties prop = new Properties();
				Path pt = new Path(context.getConfiguration().get("ubicacionProperties"));// Location of file in HDFS
				FileSystem fs = FileSystem.get(new Configuration());
				BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
				prop.load(br);
				posicion = prop.getProperty("posicionresultado");
				opcion = prop.getProperty("opciones");
			} catch (Exception e) {
			}
			origenarray = opcion.split(",");
			posirec = Integer.parseInt(posicion);
		}

		public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException {

			Configuration conf = con.getConfiguration();
			String line = value.toString();
			String[] words = line.split(",");
			if (paso == false) {
				for (int i = 0; i <= words.length - 1; i++) {
					listaid3.add(new Estructura());
				}
				paso = true;
			}
			for (int i = 0; i < words.length; i++) {
				if (listaid3.get(i).getcomponente().containsKey(words[i])) {
					int valor = listaid3.get(i).getcomponente().get(words[i]);
					listaid3.get(i).sethashmap(words[i], valor + 1);
					int array[] = new int[2];
					if (origenarray[0].equals(words[posirec])) {
						int valoractual = listaid3.get(i).getelemSalidas1(words[i]);
						int valorconservar = listaid3.get(i).getelemSalidas2(words[i]);
						array[0] = valoractual + 1;
						array[1] = valorconservar;
						listaid3.get(i).setSalidas(words[i], array);
					} else {
						int valorconservar = listaid3.get(i).getelemSalidas1(words[i]);
						int valoractual = listaid3.get(i).getelemSalidas2(words[i]);
						array[0] = valorconservar;
						array[1] = valoractual + 1;
						listaid3.get(i).setSalidas(words[i], array);
					}
				} else {
					listaid3.get(i).puthashmap(words[i], 1);
					int array[] = new int[2];
					if (origenarray[0].equals(words[posirec])) {
						array[0] = 1;
						array[1] = 0;
					} else {
						array[0] = 0;
						array[1] = 1;
					}
					listaid3.get(i).putSalidas(words[i], array);
				}
			}
			Text outputKey = new Text("");
			// Text outputKey = new Text(word.toUpperCase().trim());
			IntWritable outputValue = new IntWritable(0);
			con.write(outputKey, outputValue);
		}

		protected void cleanup(Context context) throws IOException, InterruptedException {
			Configuration conf = context.getConfiguration();
			salidas = new int[2];
			salidas[0] = 0;
			salidas[1] = 0;
			String salida = "";
			int cont = 0;
			for (String n : listaid3.get(posirec).getkey()) {
				salidas[cont] = listaid3.get(posirec).getelem(n);
				cont++;
			}

			Text t1;
			String sal = "";
			if (salidas[0] == 0 || salidas[1] == 0) {
				sal = sal + "es un caso base";
				conf.setInt("prueba", -1);
				String set = "";
				for (String n : listaid3.get(posirec).getkey()) {
					set = n;
				}
				String datos = set + ",-1";
				FileSystem fs1 = FileSystem.get(new Configuration());
				Path escribir1 = new Path(context.getConfiguration().get("ubicacionIntermedio"));
				if (fs1.exists(escribir1)) {
					fs1.delete(escribir1, true);
				}
				DataOutputStream stm1 = fs1.create(escribir1);
				stm1.writeBytes(datos);
				stm1.close();
			} else {
				t1 = new Text("Esto lo escribi en el set-up" + salida + " " + salidas[0] + " " + salidas[1]);
				ArrayList<Double> entropiasfilas = new ArrayList<Double>();
				ArrayList<Double> gananciasfilas = new ArrayList<Double>();
				double prueba = salidas[0] + salidas[1];
				double s = (double) (salidas[0]) / (prueba);
				double s1 = (double) (salidas[1]) / (prueba);
				double b = (double) (-s) * (Math.log10(s) / Math.log10(2));
				double b1 = (double) (-s1) * (Math.log10(s1) / Math.log10(2));
				Double entropiagral = b + b1;
				if (entropiagral.isNaN()) {
					sal = "no es un numero";
				} else {
					sal = "la entropia general del problema es:" + entropiagral;

				}
				for (int i = 0; i < listaid3.size() - 1; i++) {
					if (i == posirec) {
						// es una salida
						entropiasfilas.add(-2.0);
						gananciasfilas.add(-2.0);
					} else {
						ArrayList<Double> entropias = new ArrayList<Double>();
						ArrayList<Integer> numerodeveces = new ArrayList<Integer>();
						entropias.clear();
						numerodeveces.clear();
						for (String n : listaid3.get(i).getkey()) {
							int sal1 = listaid3.get(i).getelemSalidas1(n);
							int sal2 = listaid3.get(i).getelemSalidas2(n);
							double pru = sal1 + sal2;
							double sinto = (double) (sal1) / (pru);
							double s1into = (double) (sal2) / (pru);
							double binto = (double) (-sinto) * (Math.log10(sinto) / Math.log10(2));
							double b1into = (double) (-s1into) * (Math.log10(s1into) / Math.log10(2));
							Double entropiaesp = binto + b1into;
							if (entropiaesp.isNaN()) {
								entropias.add(0.0);
							} else {
								entropias.add(binto + b1into);
							}
							sal = sal + "\n la entropia especifica" + entropiaesp;
							numerodeveces.add(listaid3.get(i).getelem(n));
						}
						Double entropiagralfila = 0.0;
						Double gananciagralfila = 0.0;
						Double calculo;
						for (int j = 0; j < entropias.size(); j++) {
							calculo = entropias.get(j) * numerodeveces.get(j);
							entropiagralfila = entropiagralfila + calculo;
						}
						entropiagralfila = (double) (entropiagralfila) / (prueba);
						gananciagralfila = (double) (0.940 - entropiagralfila);
						entropiasfilas.add(entropiagralfila);
						gananciasfilas.add(gananciagralfila);
						sal = sal + "\n la entropia fila" + entropiagralfila;
						sal = sal + "\n la ganancia fila" + gananciagralfila;
					}
				}
				double valorref = -1.0;
				int fila = -1;
				for (int pbx = 0; pbx < gananciasfilas.size(); pbx++) {
					if (gananciasfilas.get(pbx) > valorref) {
						valorref = gananciasfilas.get(pbx);
						fila = pbx;
					}
				}
				sal = sal + "\n la fila con la mayor ganancia es" + fila;

				String datos = "";
				for (String n : listaid3.get(fila).getcomponente().keySet()) {
					datos = datos + n + ",";
				}
				datos = datos + fila;
				sal = sal + "\n Datos:" + datos;
				FileSystem fs1 = FileSystem.get(new Configuration());
				Path escribir1 = new Path(context.getConfiguration().get("ubicacionIntermedio"));
				if (fs1.exists(escribir1)) {
					fs1.delete(escribir1, true);
				}
				DataOutputStream stm1 = fs1.create(escribir1);
				stm1.writeBytes(datos);
				stm1.close();
			}
			t1 = new Text(sal);
			int sum = 0;
			context.write(t1, new IntWritable(sum));
		}
	}

	public static class ReduceForID3 extends Reducer<Text, IntWritable, Text, IntWritable> {
		public void reduce(Text word, Iterable<IntWritable> values, Context con)
				throws IOException, InterruptedException {

			int sum = 0;
			for (IntWritable value : values) {
				sum += value.get();
			}
			con.write(word, new IntWritable(sum));
		}
	}
}
