package AlgoritmoID3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class Estructura {	 
        //private String Elemento;
        //private int Cantidad;
        HashMap<String,Integer> componente = new HashMap<String,Integer>();
        HashMap<String,int []> salidas = new HashMap<String,int []>();
        //Soleado , 5
        //salidas : soleado 3, soleado 2
        public Estructura() {
        }
       /* public Estructura(String elem, int cant,int num1, int num2) {
        	Elemento=elem;
        	Cantidad=cant;
        	numsalida1=num1;
        	numsalida2=num2;
        }*/
        public HashMap<String,Integer> getcomponente (){
            return componente;
       }
        public void sethashmap (String palabra,int valor){
        	componente.replace(palabra, valor);
       }
        public int componentesize (){
        	return componente.size();
       }
        public void puthashmap (String palabra,int valor){
        	componente.put(palabra, valor);
       }
        public Set<String> getkey (){
        	return componente.keySet();
       }
        public int getelem (String n){
        	return componente.get(n);
       }
        public void setSalidas (String palabra,int[] valor){
        	salidas.replace(palabra, valor);
       }
        public void putSalidas (String palabra,int[] valor){
        	salidas.put(palabra, valor);
       }
        public Set<String> getkeySalidas (){
        	return salidas.keySet();
       }
       public int getelemSalidas1 (String n){
    	   /*if (salidas.get(n)[0] != null) {
    		   
    	   }*/
    	   return salidas.get(n)[0];
       }
       public int getelemSalidas2 (String n){
    	   return salidas.get(n)[1];
      }
   
}
