package PackageDemo;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.Reducer;
//import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class WordCount {
	public WordCount() {
	}

	public static void main(String[] args) throws Exception {
		Configuration c = new Configuration();
		String[] files = new GenericOptionsParser(c, args).getRemainingArgs();
		Path input = new Path(files[0]);
		Path output = new Path(files[1]);

		Job j = new Job(c, "wordcount");
		j.getConfiguration().set("properties",files[2]);
		j.setJarByClass(WordCount.class);
		j.setMapperClass(MapForWordCount.class);
		j.setReducerClass(ReduceForWordCount.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(j, input);
		FileOutputFormat.setOutputPath(j, output);

		System.exit(j.waitForCompletion(true) ? 0 : 1);
	}

	public static class MapForWordCount extends Mapper<LongWritable, Text, Text, IntWritable> {
		private double[] origenanalisis;
		private int[] posiciones;
		int[] posicioncolum;
		String[] elementos;
		String buscar = "";

		boolean encabezados = false;

		public MapForWordCount() {
		}

		protected void setup(Mapper<LongWritable, Text, Text, IntWritable>.Context context)
				throws IOException, InterruptedException {
			String origen = "";
			String posicio = "";
			String posicionescolumnas = "";
			String posicolum = "";
			Configuration conf = context.getConfiguration();
			String co=conf.get("properties");
			String elementoabuscar = "";
			try {
				Properties prop = new Properties();
				//Path pt = new Path("hdfs:/user/luminus/configuracion.properties");
				Path pt = new Path(co);
				FileSystem fs = FileSystem.get(new Configuration());
				BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
				prop.load(br);
				origen = prop.getProperty("origen");
				posicio = prop.getProperty("posiciones");
				posicolum = prop.getProperty("posicionescolumnas");
				buscar = prop.getProperty("buscar");
				if (buscar.equals("S")) {
					elementoabuscar = prop.getProperty("elementoabuscar");
					elementos = elementoabuscar.split(",");
				}
			} catch (Exception localException) {
			}

			String[] origenarray = origen.split(",");

			origenanalisis = new double[origenarray.length];
			String[] posicioarray = posicio.split(",");
			posiciones = new int[posicioarray.length];
			for (int i = 0; i < origenarray.length; i++) {
				origenanalisis[i] = Double.parseDouble(origenarray[i]);
			}
			for (int i = 0; i < posicioarray.length; i++) {
				posiciones[i] = (Integer.parseInt(posicioarray[i]) - 1);
			}
			String[] posicolum1 = posicolum.split(",");
			posicioncolum = new int[posicolum1.length];
			for (int i = 0; i < posicolum1.length; i++) {
				posicioncolum[i] = (Integer.parseInt(posicolum1[i]) - 1);
			}
		}

		public void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context con)
				throws IOException, InterruptedException {
			if (encabezados) {
				Configuration conf = con.getConfiguration();

				boolean error = false;
				String line = value.toString();
				String[] words = line.split(",");
				double[] coordenadasevaluar = new double[posiciones.length];
				for (int i = 0; i < posiciones.length; i++) {
					if (words[posiciones[i]] != null) {
						boolean result = esDoble(words[posiciones[i]]);
						if (result) {
							coordenadasevaluar[i] = Double.parseDouble(words[posiciones[i]]);
						} else {
							boolean resint = esEntero(words[posiciones[i]]);
							if (resint) {
								coordenadasevaluar[i] = Integer.parseInt(words[posiciones[i]]);
							} else {
								error = true;
							}
						}
					}
				}
				if (!error) {
					double distancia = calculardistancia(origenanalisis, coordenadasevaluar);

					String completa = "";
					for (int i = 0; i < coordenadasevaluar.length; i++) {

						completa = completa + "  " + String.valueOf(coordenadasevaluar[i]);
					}

					String clases = "";

					int contador = 0;
					for (int i = 0; i < posicioncolum.length; i++) {
						if ((buscar.equals("S")) && (words[posicioncolum[i]].equals(elementos[i]))) {
							contador++;
						}
						clases = clases + "  " + words[posicioncolum[i]];
					}

					if ((contador == posicioncolum.length) || (buscar.equals("N"))) {
						Text outputKey = new Text(String.valueOf(distancia) + ", " + completa + " clase:" + clases);
						IntWritable outputValue = new IntWritable(1);
						con.write(outputKey, outputValue);
					}
				}
			} else {
				encabezados = true;
			}
		}

		public static boolean esEntero(String cadena) {
			try {
				Integer.parseInt(cadena);
				return true;
			} catch (NumberFormatException excepcion) {
			}
			return false;
		}

		public boolean esDoble(String palabra) {
			try {
				Double.parseDouble(palabra);
				return true;
			} catch (NumberFormatException e) {
			}
			return false;
		}

		public double calculardistancia(double[] c1, double[] c2) {
			double result = 0.0D;
			double todo = 0.0D;
			for (int i = 0; i < c1.length; i++) {
				result = c1[i] - c2[i];
				result = Math.pow(result, 2.0D);
				todo += result;
			}
			double raiz = Math.sqrt(todo);
			return raiz;
		}
	}

	public static class ReduceForWordCount extends Reducer<Text, IntWritable, Text, IntWritable> {
		public ReduceForWordCount() {
		}
		String valork = "";
		String pathsalidacompleta = "";
		String pathsalidaordenadacompleta = "";
		String pathsalidak = "";
		String pathsalidaexcel = "";
		DataOutputStream stm = null;
		DataOutputStream streamExcel = null;

		protected void setup(Reducer<Text, IntWritable, Text, IntWritable>.Context context)
				throws IOException, InterruptedException {		
			Configuration conf = context.getConfiguration();
			String co=conf.get("properties");
			HashMap<Double, String> puntosobtenidos = new HashMap();
			ArrayList<String> completo = new ArrayList();
			try {
				Properties prop = new Properties();
				//Path pt = new Path("hdfs:/user/luminus/configuracion.properties");
				Path pt = new Path(co);
				FileSystem fs = FileSystem.get(new Configuration());
				BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
				prop.load(br);
				valork = prop.getProperty("K");
				pathsalidacompleta = prop.getProperty("pathsalidacompleta");
				pathsalidaordenadacompleta = prop.getProperty("pathsalidaordenadacompleta");
				pathsalidak = prop.getProperty("pathsalidak");
				pathsalidaexcel = prop.getProperty("pathsalidaexcel");
			} catch (Exception localException) {
			}
			FileSystem fs1 = FileSystem.get(new Configuration());
		    Path escribir=new Path(pathsalidacompleta);
			 if (fs1.exists(escribir)) {
				    fs1.delete(escribir, true);
				  }
			 stm = fs1.create(escribir);

		}

		public void reduce(Text word, Iterable<IntWritable> values,
				Reducer<Text, IntWritable, Text, IntWritable>.Context con) throws IOException, InterruptedException {
			String line = word.toString();
			String[] resultado = line.split(",");
			
			int sum = 0;
			for (IntWritable value : values) {
				sum += value.get();
			}
			stm.writeBytes(line + " aparece: " + sum);
			stm.writeBytes("\n");
			con.write(word, new IntWritable(sum));
		}
		protected void cleanup(Context context) throws IOException, InterruptedException {
			String valork = "";
			String pathsalidacompleta = "";
			String pathsalidaordenadacompleta = "";
			String pathsalidak = "";
			String pathsalidaexcel = "";
			Configuration conf = context.getConfiguration();
			String co=conf.get("properties");
			HashMap<Double, String> puntosobtenidos = new HashMap();
			ArrayList<String> completo = new ArrayList();
			try {
				Properties prop = new Properties();
				//Path pt = new Path("hdfs:/user/luminus/configuracion.properties");
				Path pt = new Path(co);
				FileSystem fs = FileSystem.get(new Configuration());
				BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(pt)));
				prop.load(br);
				valork = prop.getProperty("K");
				pathsalidacompleta = prop.getProperty("pathsalidacompleta");
				pathsalidaordenadacompleta = prop.getProperty("pathsalidaordenadacompleta");
				pathsalidak = prop.getProperty("pathsalidak");
				pathsalidaexcel = prop.getProperty("pathsalidaexcel");
			} catch (Exception localException) {
			}
			int numk = Integer.valueOf(valork).intValue();
			BufferedReader br;
			try {
				Path pt = new Path(pathsalidacompleta);
				FileSystem fs = FileSystem.get(new Configuration());
				br = new BufferedReader(new InputStreamReader(fs.open(pt)));

				String linealeida = br.readLine();
				while (linealeida != null) {
					String[] resultado = linealeida.split(",");
					puntosobtenidos.put(Double.valueOf(Double.parseDouble(resultado[0])), resultado[1]);
					completo.add(linealeida);
					linealeida = br.readLine();
				}
			} catch (Exception localException1) {
			}

			List<Double> ordenar = new ArrayList();

			for (Double n : puntosobtenidos.keySet()) {
				ordenar.add(n);
			}

			Collections.sort(ordenar);

			FileSystem fs1 = FileSystem.get(new Configuration());
			Path escribir1 = new Path(pathsalidaordenadacompleta);
			if (fs1.exists(escribir1)) {
				fs1.delete(escribir1, true);
			}

			DataOutputStream stm1 = fs1.create(escribir1);

			for (int i = 0; i < ordenar.size(); i++) {
				stm1.writeBytes("Distancia: " + ordenar.get(i) + " que corresponde a: "
						+ (String) puntosobtenidos.get(ordenar.get(i)));
				stm1.writeBytes("\n");
			}
			stm1.close();

			FileSystem fs = FileSystem.get(new Configuration());
			Path escribir = new Path(pathsalidak);
			if (fs.exists(escribir)) {
				fs.delete(escribir, true);
			}
			DataOutputStream stm = fs.create(escribir);

			ArrayList<String> elemento = new ArrayList();
			ArrayList<Integer> repite = new ArrayList();
			stm.writeBytes("se solicito un k=" + numk + " se listan estos k nodos \n");
			for (int i = 0; i < ordenar.size(); i++) {
				if (i < numk) {
					stm.writeBytes("Distancia: " + ordenar.get(i) + " que corresponde a: "
							+ (String) puntosobtenidos.get(ordenar.get(i)));
					stm.writeBytes("\n");
					String despuesdeclase = ((String) puntosobtenidos.get(ordenar.get(i))).substring(
							((String) puntosobtenidos.get(ordenar.get(i))).indexOf("clase"),
							((String) puntosobtenidos.get(ordenar.get(i))).indexOf("aparece:"));
					if (elemento.contains(despuesdeclase)) {
						int value = elemento.indexOf(despuesdeclase);
						int contenido = ((Integer) repite.get(value)).intValue();
						repite.set(value, Integer.valueOf(contenido + 1));
					} else {
						elemento.add(despuesdeclase);
						repite.add(Integer.valueOf(1));
					}
				}
			}
			int posicion = 0;
			int mayor = -1;
			for (int i = 0; i < elemento.size(); i++) {
				if (((Integer) repite.get(i)).intValue() > mayor) {
					posicion = i;
					mayor = ((Integer) repite.get(i)).intValue();
				}
			}

			for (int i = 0; i < elemento.size(); i++) {
				if (i == 0) {
					if (mayor == 1) {
						stm.writeBytes("no hay una clase a la que pertenezca ya que los resultados no fueron concluyentes");
					} else {
						stm.writeBytes("pertenece a" + (String) elemento.get(i) + " la cual forma parte de " + mayor
								+ "k cercanos");
					}
				}
			}
			stm.close();

			FileSystem sistemaExcel = FileSystem.get(new Configuration());
			Path pathArchivoExcel = new Path(pathsalidaexcel);
			if (fs1.exists(pathArchivoExcel)) {
				fs1.delete(pathArchivoExcel, true);
			}

			DataOutputStream streamExcel = sistemaExcel.create(pathArchivoExcel);
			// String[] fila;
			HashMap<Double, String> mapaDatosExcel = new HashMap();
			String filaExcel;
			try {
				BufferedReader lectorExcel = new BufferedReader(new InputStreamReader(sistemaExcel.open(escribir1)));
				filaExcel = lectorExcel.readLine();
				while (filaExcel != null) {
					String[] fila = filaExcel.split(",");
					mapaDatosExcel.put(Double.valueOf(Double.parseDouble(fila[0])), fila[1]);
					filaExcel = lectorExcel.readLine();
				}
			} catch (Exception localException2) {
			}

			HashMap<Double, String> puntosObtenidosParaExcel = puntosobtenidos;

			streamExcel.writeBytes("Distancia\t Ubicacion\n");
			List<String> subcadenas = new ArrayList();
			for (Double punto : ordenar) {
				subcadenas.add((String) puntosObtenidosParaExcel.get(punto));
			}
			Integer contador = Integer.valueOf(0);
			for (Double punto : ordenar) {
				streamExcel.writeBytes(punto.toString() + "\t" + (String) subcadenas.get(contador.intValue()) + "\n");
				contador = Integer.valueOf(contador.intValue() + 1);
			}
			streamExcel.close();
		}
	}
}
